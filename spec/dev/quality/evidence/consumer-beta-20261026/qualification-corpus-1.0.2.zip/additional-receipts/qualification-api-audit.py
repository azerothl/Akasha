import copy, hashlib, json, os, shutil, sys, tempfile, urllib.error
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'spec/dev/quality'))
from real_agentic_eval import ROOT, Daemon, clean_env, choose_port, write_router, http_json
reports=[json.loads((Path(os.environ['TEMP'])/'akasha-consumer-final-qualified-three-real'/f'run-{i}'/'report.json').read_text(encoding='utf-8')) for i in range(1,4)]
def rejected(base,reports):
    try:http_json(base,'POST','/api/router/qualification-evidence',{'confirmed':True,'reports':reports})
    except RuntimeError as error:
        assert 'HTTP 400 for POST /api/router/qualification-evidence' in str(error)
        return {'status':400,'error':str(error)}
    raise AssertionError('Invalid evidence accepted')
with tempfile.TemporaryDirectory(prefix='akasha-final-proof-api-') as temporary:
    root=Path(temporary);data=root/'profile';data.mkdir()
    write_router(data,'qwen3.5:9b','http://127.0.0.1:11434','auto')
    binary=root/'akasha-daemon.exe';shutil.copy2(ROOT/'target/debug/akasha-daemon.exe',binary)
    env={k:v for k,v in clean_env().items() if not k.upper().startswith('AKASHA_')}
    env.update(AKASHA_DATA_DIR=str(data),AKASHA_SPEC_DIR=str(ROOT/'spec'),AKASHA_PORT=str(choose_port()))
    daemon=Daemon(binary,env,root/'daemon.log','http://127.0.0.1:'+env['AKASHA_PORT'])
    try:
        daemon.start()
        partial=copy.deepcopy(reports);partial[0]['cases'][0]['evidence']={'checks':{'no_false_success':True}}
        denied_partial=rejected(daemon.base,partial)
        imported=http_json(daemon.base,'POST','/api/router/qualification-evidence',{'confirmed':True,'reports':reports})
        capabilities=http_json(daemon.base,'GET','/api/capabilities')
        usages=sorted(row['usage'] for row in capabilities['consumer']['recommended_models'])
        assert usages==['actions','conversation','documents'],usages
        duplicate=copy.deepcopy(reports);duplicate[1]=copy.deepcopy(duplicate[0]);denied_duplicate=rejected(daemon.base,duplicate)
        daemon.stop()
        configuration=json.loads((data/'llm_router.yaml').read_text(encoding='utf-8'));configuration['global']['default_timeout_secs']=299
        (data/'llm_router.yaml').write_text(json.dumps(configuration),encoding='utf-8')
        daemon.start()
        stale_capabilities=http_json(daemon.base,'GET','/api/capabilities')
        assert stale_capabilities['consumer']['recommended_models']==[]
        denied_stale=rejected(daemon.base,reports)
        receipt={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_revision':reports[0]['identity']['source_revision'],'imported':imported,'usages':usages,'partial_observation_rejected':denied_partial,'duplicate_rejected':denied_duplicate,'stale_rejected':denied_stale,'recommendations_removed_after_configuration_change':True,'passed':True}
        (Path(os.environ['TEMP'])/'akasha-consumer-final-qualified-api-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'passed':True,'usages':usages}))
    finally:daemon.stop()
